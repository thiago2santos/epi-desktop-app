/**
 * Persistência do índice CAEPI no IndexedDB (protótipo / demo com base completa).
 */
(function (global) {
  const DB_NAME = 'enr6_mock_caepi_v1';
  const DB_VERSION = 1;
  const STORE_CA = 'ca';

  function openDb() {
    return new Promise(function (resolve, reject) {
      if (!global.indexedDB) {
        reject(new Error('IndexedDB não disponível neste navegador.'));
        return;
      }
      const req = global.indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = function () {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_CA)) {
          db.createObjectStore(STORE_CA, { keyPath: 'caNumber' });
        }
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { reject(req.error || new Error('Falha ao abrir IndexedDB')); };
    });
  }

  function replaceIndex(index, onProgress) {
    const entries = Object.values(index || {});
    return openDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        const tx = db.transaction(STORE_CA, 'readwrite');
        const store = tx.objectStore(STORE_CA);
        store.clear();
        let n = 0;
        entries.forEach(function (entry) {
          store.put(entry);
          n++;
          if (onProgress && n % 8000 === 0) {
            onProgress({ phase: 'idb', written: n, total: entries.length });
          }
        });
        tx.oncomplete = function () {
          if (onProgress) onProgress({ phase: 'idb', written: entries.length, total: entries.length, done: true });
          db.close();
          resolve(entries.length);
        };
        tx.onerror = function () {
          db.close();
          reject(tx.error);
        };
      });
    });
  }

  function loadAll(onProgress) {
    return openDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        const tx = db.transaction(STORE_CA, 'readonly');
        const req = tx.objectStore(STORE_CA).openCursor();
        const index = {};
        let n = 0;
        req.onsuccess = function (ev) {
          const cursor = ev.target.result;
          if (cursor) {
            index[cursor.value.caNumber] = cursor.value;
            n++;
            if (onProgress && n % 8000 === 0) onProgress({ phase: 'hydrate', loaded: n });
            cursor.continue();
          } else {
            if (onProgress) onProgress({ phase: 'hydrate', loaded: n, done: true });
            db.close();
            resolve(index);
          }
        };
        req.onerror = function () {
          db.close();
          reject(req.error);
        };
      });
    });
  }

  function getOne(caNumber) {
    return openDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        const tx = db.transaction(STORE_CA, 'readonly');
        const req = tx.objectStore(STORE_CA).get(String(caNumber));
        req.onsuccess = function () {
          db.close();
          resolve(req.result || null);
        };
        req.onerror = function () {
          db.close();
          reject(req.error);
        };
      });
    });
  }

  function count() {
    return openDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        const tx = db.transaction(STORE_CA, 'readonly');
        const req = tx.objectStore(STORE_CA).count();
        req.onsuccess = function () {
          db.close();
          resolve(req.result || 0);
        };
        req.onerror = function () {
          db.close();
          reject(req.error);
        };
      });
    });
  }

  function clearStore() {
    return openDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        const tx = db.transaction(STORE_CA, 'readwrite');
        tx.objectStore(STORE_CA).clear();
        tx.oncomplete = function () {
          db.close();
          resolve();
        };
        tx.onerror = function () {
          db.close();
          reject(tx.error);
        };
      });
    });
  }

  global.Enr6CaepiIdb = {
    replaceIndex,
    loadAll,
    getOne,
    count,
    clearStore,
    DB_NAME,
  };
})(typeof window !== 'undefined' ? window : globalThis);
